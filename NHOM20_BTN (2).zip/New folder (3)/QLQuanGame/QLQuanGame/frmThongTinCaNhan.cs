﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QLQuanGame
{
    public partial class frmThongTinCaNhan : Form
    {
        SqlConnection conn = new SqlConnection(@"Data Source=MSI\SQLEXPRESS;Initial Catalog=qlqgamee;Integrated Security=True");
        SqlCommand cmd;
        public frmThongTinCaNhan()
        {
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void frmThongTinCaNhan_Load(object sender, EventArgs e)
        {
            conn.Open();
            string query = $"select * from NhanVien where username = '{frmDangNhap.username}'";
            cmd = new SqlCommand(query, conn);
            SqlDataReader reader = cmd.ExecuteReader();

            if (reader.Read())
            {
                // Đọc giá trị từ cột và gán vào TextBox tương ứng
                txtHoTen.Text = reader["hoten"].ToString();
                txtemail.Text = reader["email"].ToString();
                txtMaNV.Text = reader["idnhanvien"].ToString() ;
                txtSDT.Text = reader["sdt"].ToString();
                //cbxGioiTinh.ValueMember = reader["gioitinh"].ToString();
                // Gán giá trị cho ComboBox gioitinh (nếu có)
                object gioiTinhValue = reader["gioitinh"];
                if (gioiTinhValue != null && gioiTinhValue != DBNull.Value)
                {
                    string gioiTinh = gioiTinhValue.ToString();
                    // Kiểm tra xem giá trị có tồn tại trong ComboBox hay không
                    if (cbxGioiTinh.Items.Contains(gioiTinh))
                    {
                        cbxGioiTinh.SelectedItem = gioiTinh;
                    }
                    else
                    {
                        // Nếu không tồn tại, thêm giá trị vào ComboBox
                        cbxGioiTinh.Items.Add(gioiTinh);
                        cbxGioiTinh.SelectedItem = gioiTinh;
                    }
                }
                // Gán giá trị cho ComboBox gioitinh (nếu có)
                object quequanValue = reader["quequan"];
                if (quequanValue != null && quequanValue != DBNull.Value)
                {
                    string quequan = quequanValue.ToString();
                    // Kiểm tra xem giá trị có tồn tại trong ComboBox hay không
                    if (cbxQueQuan.Items.Contains(quequan))
                    {
                        cbxQueQuan.SelectedItem = quequan;
                    }
                    else
                    {
                        // Nếu không tồn tại, thêm giá trị vào ComboBox
                        cbxQueQuan.Items.Add(quequan);
                        cbxQueQuan.SelectedItem = quequan;
                    }
                }

                // Gán giá trị cho DateTimePicker ngaysinh
                object ngaySinhValue = reader["ngaysinh"];
                if (ngaySinhValue != null && ngaySinhValue != DBNull.Value)
                {
                    // Chuyển đổi giá trị về kiểu DateTime và gán cho DateTimePicker
                    dtpkNgaySinh.Value = Convert.ToDateTime(ngaySinhValue);
                }

                // Đóng SqlDataReader sau khi sử dụng
                reader.Close();
                conn.Close();
            }

        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            try
            {
                conn.Open();
                MessageBox.Show("Connection opened");
                string register = $"update NhanVien set hoten = N'{txtHoTen.Text}', email = N'{txtemail.Text}', sdt = '{txtSDT.Text}', gioitinh = N'{cbxGioiTinh.SelectedItem}', quequan = N'{cbxQueQuan.SelectedItem}', ngaysinh = '{dtpkNgaySinh.Value}' where idnhanvien = '{txtMaNV.Text}'";
                cmd = new SqlCommand(register, conn);
                cmd.ExecuteNonQuery();
                conn.Close();
                MessageBox.Show("Thay doi thanh cong!");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
