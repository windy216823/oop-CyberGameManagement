﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QLQuanGame
{
    public partial class frmQLKhach : Form
    {
        SqlConnection connection;
        SqlCommand command;
        string str = @"Data Source=MSI\SQLEXPRESS;Initial Catalog=qlqgamee;Integrated Security=True";
        SqlDataAdapter adapter = new SqlDataAdapter();
        DataTable table = new DataTable();
        void loadData()
        {
            command = connection.CreateCommand();
            command.CommandText = "Select * from Khach";
            adapter.SelectCommand = command;
            table.Clear();
            adapter.Fill(table);
            dgvListKhach.DataSource = table;
        }
        public frmQLKhach()
        {
            InitializeComponent();
        }

        private void frmQLKhach_Load(object sender, EventArgs e)
        {
            connection = new SqlConnection(str);
            connection.Open();
            loadData();
        }

        private void guna2Button2_Click(object sender, EventArgs e)
        {
            command = connection.CreateCommand();
            command.CommandText = $"select * from Khach where accountname = '{txtUserName.Text}' ";
            command.ExecuteNonQuery();
            
        }

        private void btnCapNhat_Click(object sender, EventArgs e)
        {
            command = connection.CreateCommand();
            command.CommandText = $"update Khach set accountname = {txtUserName.Text}, password = {txtMK.Text}, sdt = {txtsdt.Text}";
            command.ExecuteNonQuery();
            loadData();
        }

        private void btnXoa_Click(object sender, EventArgs e)
        {
            command = connection.CreateCommand();
            command.CommandText = "delete from Khach where accountname = '" + txtUserName.Text + "'";
            command.ExecuteNonQuery();
            loadData();
        }

        private void dgvListKhach_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            int i;
            i = dgvListKhach.CurrentRow.Index;
            txtUserName.Text = dgvListKhach.Rows[i].Cells[1].Value.ToString();
            txtMK.Text = dgvListKhach.Rows[i].Cells[2].Value.ToString();
            txtsdt.Text = dgvListKhach.Rows[i].Cells[4].Value.ToString();
        }
    }
}
