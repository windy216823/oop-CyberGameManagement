﻿namespace QLQuanGame
{
    partial class frmGiaodien
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmGiaodien));
            this.panelheader = new System.Windows.Forms.Panel();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.btnclose = new System.Windows.Forms.Button();
            this.panelside = new System.Windows.Forms.Panel();
            this.panelThongKe = new System.Windows.Forms.Panel();
            this.btnSuCo = new System.Windows.Forms.Button();
            this.btnTKNgay = new System.Windows.Forms.Button();
            this.btnTKthang = new System.Windows.Forms.Button();
            this.btnThongKe = new System.Windows.Forms.Button();
            this.btnMay = new System.Windows.Forms.Button();
            this.btnNapTien = new System.Windows.Forms.Button();
            this.btnThemTK = new System.Windows.Forms.Button();
            this.panelDanhMuc = new System.Windows.Forms.Panel();
            this.btnGiaoDich = new System.Windows.Forms.Button();
            this.btnQLDichVu = new System.Windows.Forms.Button();
            this.btnQLMay = new System.Windows.Forms.Button();
            this.btnKhach = new System.Windows.Forms.Button();
            this.btnNhanVien = new System.Windows.Forms.Button();
            this.btnDanhMuc = new System.Windows.Forms.Button();
            this.panelHeThong = new System.Windows.Forms.Panel();
            this.btnDangKi = new System.Windows.Forms.Button();
            this.btnDoiMK = new System.Windows.Forms.Button();
            this.btnThongTinCN = new System.Windows.Forms.Button();
            this.btnHeThong = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.mainpanel = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.panelheader.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.panelside.SuspendLayout();
            this.panelThongKe.SuspendLayout();
            this.panelDanhMuc.SuspendLayout();
            this.panelHeThong.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.mainpanel.SuspendLayout();
            this.SuspendLayout();
            // 
            // panelheader
            // 
            this.panelheader.BackColor = System.Drawing.Color.Gray;
            this.panelheader.Controls.Add(this.pictureBox2);
            this.panelheader.Controls.Add(this.label1);
            this.panelheader.Controls.Add(this.btnclose);
            this.panelheader.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelheader.Location = new System.Drawing.Point(0, 0);
            this.panelheader.Margin = new System.Windows.Forms.Padding(4);
            this.panelheader.Name = "panelheader";
            this.panelheader.Size = new System.Drawing.Size(1067, 37);
            this.panelheader.TabIndex = 2;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(1, 0);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(31, 37);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 3;
            this.pictureBox2.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Gray;
            this.label1.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.label1.Font = new System.Drawing.Font("Harlow Solid Italic", 13.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label1.Location = new System.Drawing.Point(40, 4);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(471, 29);
            this.label1.TabIndex = 2;
            this.label1.Text = "Game cyber management system - Version 1.0";
            // 
            // btnclose
            // 
            this.btnclose.BackColor = System.Drawing.Color.Gray;
            this.btnclose.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnclose.FlatAppearance.BorderSize = 0;
            this.btnclose.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnclose.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnclose.ForeColor = System.Drawing.Color.White;
            this.btnclose.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnclose.Location = new System.Drawing.Point(1027, 0);
            this.btnclose.Margin = new System.Windows.Forms.Padding(4);
            this.btnclose.Name = "btnclose";
            this.btnclose.Size = new System.Drawing.Size(40, 37);
            this.btnclose.TabIndex = 1;
            this.btnclose.Text = "X";
            this.btnclose.UseVisualStyleBackColor = false;
            this.btnclose.Click += new System.EventHandler(this.btnclose_Click);
            // 
            // panelside
            // 
            this.panelside.BackColor = System.Drawing.Color.DimGray;
            this.panelside.Controls.Add(this.panelThongKe);
            this.panelside.Controls.Add(this.btnThongKe);
            this.panelside.Controls.Add(this.btnMay);
            this.panelside.Controls.Add(this.btnNapTien);
            this.panelside.Controls.Add(this.btnThemTK);
            this.panelside.Controls.Add(this.panelDanhMuc);
            this.panelside.Controls.Add(this.btnDanhMuc);
            this.panelside.Controls.Add(this.panelHeThong);
            this.panelside.Controls.Add(this.btnHeThong);
            this.panelside.Controls.Add(this.panel1);
            this.panelside.Dock = System.Windows.Forms.DockStyle.Left;
            this.panelside.Font = new System.Drawing.Font("Microsoft YaHei UI", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panelside.Location = new System.Drawing.Point(0, 37);
            this.panelside.Margin = new System.Windows.Forms.Padding(4);
            this.panelside.Name = "panelside";
            this.panelside.Size = new System.Drawing.Size(267, 563);
            this.panelside.TabIndex = 3;
            // 
            // panelThongKe
            // 
            this.panelThongKe.Controls.Add(this.btnSuCo);
            this.panelThongKe.Controls.Add(this.btnTKNgay);
            this.panelThongKe.Controls.Add(this.btnTKthang);
            this.panelThongKe.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelThongKe.Location = new System.Drawing.Point(0, 475);
            this.panelThongKe.Name = "panelThongKe";
            this.panelThongKe.Size = new System.Drawing.Size(267, 126);
            this.panelThongKe.TabIndex = 14;
            // 
            // btnSuCo
            // 
            this.btnSuCo.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btnSuCo.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnSuCo.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnSuCo.FlatAppearance.BorderSize = 0;
            this.btnSuCo.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSuCo.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSuCo.ForeColor = System.Drawing.Color.White;
            this.btnSuCo.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnSuCo.Location = new System.Drawing.Point(0, 74);
            this.btnSuCo.Margin = new System.Windows.Forms.Padding(4);
            this.btnSuCo.Name = "btnSuCo";
            this.btnSuCo.Size = new System.Drawing.Size(267, 37);
            this.btnSuCo.TabIndex = 9;
            this.btnSuCo.Text = "SỰ CỐ";
            this.btnSuCo.UseVisualStyleBackColor = false;
            this.btnSuCo.Click += new System.EventHandler(this.btnSuCo_Click);
            // 
            // btnTKNgay
            // 
            this.btnTKNgay.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btnTKNgay.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnTKNgay.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnTKNgay.FlatAppearance.BorderSize = 0;
            this.btnTKNgay.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnTKNgay.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTKNgay.ForeColor = System.Drawing.Color.White;
            this.btnTKNgay.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnTKNgay.Location = new System.Drawing.Point(0, 37);
            this.btnTKNgay.Margin = new System.Windows.Forms.Padding(4);
            this.btnTKNgay.Name = "btnTKNgay";
            this.btnTKNgay.Size = new System.Drawing.Size(267, 37);
            this.btnTKNgay.TabIndex = 8;
            this.btnTKNgay.Text = "THỐNG KÊ THEO NGÀY";
            this.btnTKNgay.UseVisualStyleBackColor = false;
            this.btnTKNgay.Click += new System.EventHandler(this.btnTKNgay_Click);
            // 
            // btnTKthang
            // 
            this.btnTKthang.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btnTKthang.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnTKthang.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnTKthang.FlatAppearance.BorderSize = 0;
            this.btnTKthang.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnTKthang.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTKthang.ForeColor = System.Drawing.Color.White;
            this.btnTKthang.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnTKthang.Location = new System.Drawing.Point(0, 0);
            this.btnTKthang.Margin = new System.Windows.Forms.Padding(4);
            this.btnTKthang.Name = "btnTKthang";
            this.btnTKthang.Size = new System.Drawing.Size(267, 37);
            this.btnTKthang.TabIndex = 7;
            this.btnTKthang.Text = "THỐNG KÊ THEO THÁNG";
            this.btnTKthang.UseVisualStyleBackColor = false;
            this.btnTKthang.Click += new System.EventHandler(this.btnTKthang_Click);
            // 
            // btnThongKe
            // 
            this.btnThongKe.BackColor = System.Drawing.Color.DimGray;
            this.btnThongKe.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnThongKe.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnThongKe.FlatAppearance.BorderSize = 0;
            this.btnThongKe.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnThongKe.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnThongKe.ForeColor = System.Drawing.Color.White;
            this.btnThongKe.Image = ((System.Drawing.Image)(resources.GetObject("btnThongKe.Image")));
            this.btnThongKe.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnThongKe.Location = new System.Drawing.Point(0, 438);
            this.btnThongKe.Margin = new System.Windows.Forms.Padding(4);
            this.btnThongKe.Name = "btnThongKe";
            this.btnThongKe.Size = new System.Drawing.Size(267, 37);
            this.btnThongKe.TabIndex = 13;
            this.btnThongKe.Text = "THỐNG KÊ";
            this.btnThongKe.UseVisualStyleBackColor = false;
            this.btnThongKe.Click += new System.EventHandler(this.btnThongKe_Click);
            // 
            // btnMay
            // 
            this.btnMay.BackColor = System.Drawing.Color.DimGray;
            this.btnMay.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnMay.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnMay.FlatAppearance.BorderSize = 0;
            this.btnMay.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnMay.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMay.ForeColor = System.Drawing.Color.White;
            this.btnMay.Image = ((System.Drawing.Image)(resources.GetObject("btnMay.Image")));
            this.btnMay.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnMay.Location = new System.Drawing.Point(0, 401);
            this.btnMay.Margin = new System.Windows.Forms.Padding(4);
            this.btnMay.Name = "btnMay";
            this.btnMay.Size = new System.Drawing.Size(267, 37);
            this.btnMay.TabIndex = 12;
            this.btnMay.Text = "MÁY";
            this.btnMay.UseVisualStyleBackColor = false;
            this.btnMay.Click += new System.EventHandler(this.btnMay_Click);
            // 
            // btnNapTien
            // 
            this.btnNapTien.BackColor = System.Drawing.Color.DimGray;
            this.btnNapTien.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnNapTien.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnNapTien.FlatAppearance.BorderSize = 0;
            this.btnNapTien.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnNapTien.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNapTien.ForeColor = System.Drawing.Color.White;
            this.btnNapTien.Image = ((System.Drawing.Image)(resources.GetObject("btnNapTien.Image")));
            this.btnNapTien.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnNapTien.Location = new System.Drawing.Point(0, 364);
            this.btnNapTien.Margin = new System.Windows.Forms.Padding(4);
            this.btnNapTien.Name = "btnNapTien";
            this.btnNapTien.Size = new System.Drawing.Size(267, 37);
            this.btnNapTien.TabIndex = 10;
            this.btnNapTien.Text = "NẠP TIỀN";
            this.btnNapTien.UseVisualStyleBackColor = false;
            this.btnNapTien.Click += new System.EventHandler(this.btnNapTien_Click);
            // 
            // btnThemTK
            // 
            this.btnThemTK.BackColor = System.Drawing.Color.DimGray;
            this.btnThemTK.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnThemTK.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnThemTK.FlatAppearance.BorderSize = 0;
            this.btnThemTK.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnThemTK.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnThemTK.ForeColor = System.Drawing.Color.White;
            this.btnThemTK.Image = ((System.Drawing.Image)(resources.GetObject("btnThemTK.Image")));
            this.btnThemTK.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnThemTK.Location = new System.Drawing.Point(0, 327);
            this.btnThemTK.Margin = new System.Windows.Forms.Padding(4);
            this.btnThemTK.Name = "btnThemTK";
            this.btnThemTK.Size = new System.Drawing.Size(267, 37);
            this.btnThemTK.TabIndex = 8;
            this.btnThemTK.Text = "THÊM ACCOUNT KHÁCH";
            this.btnThemTK.UseVisualStyleBackColor = false;
            this.btnThemTK.Click += new System.EventHandler(this.btnThemTK_Click);
            // 
            // panelDanhMuc
            // 
            this.panelDanhMuc.Controls.Add(this.btnGiaoDich);
            this.panelDanhMuc.Controls.Add(this.btnQLDichVu);
            this.panelDanhMuc.Controls.Add(this.btnQLMay);
            this.panelDanhMuc.Controls.Add(this.btnKhach);
            this.panelDanhMuc.Controls.Add(this.btnNhanVien);
            this.panelDanhMuc.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelDanhMuc.Location = new System.Drawing.Point(0, 305);
            this.panelDanhMuc.Name = "panelDanhMuc";
            this.panelDanhMuc.Size = new System.Drawing.Size(267, 22);
            this.panelDanhMuc.TabIndex = 7;
            // 
            // btnGiaoDich
            // 
            this.btnGiaoDich.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btnGiaoDich.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnGiaoDich.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnGiaoDich.FlatAppearance.BorderSize = 0;
            this.btnGiaoDich.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnGiaoDich.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnGiaoDich.ForeColor = System.Drawing.Color.White;
            this.btnGiaoDich.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnGiaoDich.Location = new System.Drawing.Point(0, 148);
            this.btnGiaoDich.Margin = new System.Windows.Forms.Padding(4);
            this.btnGiaoDich.Name = "btnGiaoDich";
            this.btnGiaoDich.Size = new System.Drawing.Size(267, 37);
            this.btnGiaoDich.TabIndex = 11;
            this.btnGiaoDich.Text = "QUẢN LÍ GIAO DỊCH";
            this.btnGiaoDich.UseVisualStyleBackColor = false;
            this.btnGiaoDich.Click += new System.EventHandler(this.btnGiaoDich_Click);
            // 
            // btnQLDichVu
            // 
            this.btnQLDichVu.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btnQLDichVu.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnQLDichVu.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnQLDichVu.FlatAppearance.BorderSize = 0;
            this.btnQLDichVu.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnQLDichVu.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnQLDichVu.ForeColor = System.Drawing.Color.White;
            this.btnQLDichVu.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnQLDichVu.Location = new System.Drawing.Point(0, 111);
            this.btnQLDichVu.Margin = new System.Windows.Forms.Padding(4);
            this.btnQLDichVu.Name = "btnQLDichVu";
            this.btnQLDichVu.Size = new System.Drawing.Size(267, 37);
            this.btnQLDichVu.TabIndex = 10;
            this.btnQLDichVu.Text = "QUẢN LÍ DỊCH VỤ";
            this.btnQLDichVu.UseVisualStyleBackColor = false;
            this.btnQLDichVu.Click += new System.EventHandler(this.btnQLDichVu_Click);
            // 
            // btnQLMay
            // 
            this.btnQLMay.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btnQLMay.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnQLMay.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnQLMay.FlatAppearance.BorderSize = 0;
            this.btnQLMay.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnQLMay.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnQLMay.ForeColor = System.Drawing.Color.White;
            this.btnQLMay.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnQLMay.Location = new System.Drawing.Point(0, 74);
            this.btnQLMay.Margin = new System.Windows.Forms.Padding(4);
            this.btnQLMay.Name = "btnQLMay";
            this.btnQLMay.Size = new System.Drawing.Size(267, 37);
            this.btnQLMay.TabIndex = 9;
            this.btnQLMay.Text = "QUẢN LÍ MÁY";
            this.btnQLMay.UseVisualStyleBackColor = false;
            this.btnQLMay.Click += new System.EventHandler(this.btnQLMay_Click);
            // 
            // btnKhach
            // 
            this.btnKhach.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btnKhach.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnKhach.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnKhach.FlatAppearance.BorderSize = 0;
            this.btnKhach.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnKhach.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnKhach.ForeColor = System.Drawing.Color.White;
            this.btnKhach.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnKhach.Location = new System.Drawing.Point(0, 37);
            this.btnKhach.Margin = new System.Windows.Forms.Padding(4);
            this.btnKhach.Name = "btnKhach";
            this.btnKhach.Size = new System.Drawing.Size(267, 37);
            this.btnKhach.TabIndex = 8;
            this.btnKhach.Text = "QUẢN LÍ KHÁCH";
            this.btnKhach.UseVisualStyleBackColor = false;
            this.btnKhach.Click += new System.EventHandler(this.btnKhach_Click);
            // 
            // btnNhanVien
            // 
            this.btnNhanVien.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btnNhanVien.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnNhanVien.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnNhanVien.FlatAppearance.BorderSize = 0;
            this.btnNhanVien.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnNhanVien.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNhanVien.ForeColor = System.Drawing.Color.White;
            this.btnNhanVien.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnNhanVien.Location = new System.Drawing.Point(0, 0);
            this.btnNhanVien.Margin = new System.Windows.Forms.Padding(4);
            this.btnNhanVien.Name = "btnNhanVien";
            this.btnNhanVien.Size = new System.Drawing.Size(267, 37);
            this.btnNhanVien.TabIndex = 7;
            this.btnNhanVien.Text = "QUẢN LÍ NHÂN VIÊN";
            this.btnNhanVien.UseVisualStyleBackColor = false;
            this.btnNhanVien.Click += new System.EventHandler(this.btnNhanVien_Click);
            // 
            // btnDanhMuc
            // 
            this.btnDanhMuc.BackColor = System.Drawing.Color.DimGray;
            this.btnDanhMuc.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnDanhMuc.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnDanhMuc.FlatAppearance.BorderSize = 0;
            this.btnDanhMuc.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDanhMuc.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDanhMuc.ForeColor = System.Drawing.Color.White;
            this.btnDanhMuc.Image = ((System.Drawing.Image)(resources.GetObject("btnDanhMuc.Image")));
            this.btnDanhMuc.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnDanhMuc.Location = new System.Drawing.Point(0, 268);
            this.btnDanhMuc.Margin = new System.Windows.Forms.Padding(4);
            this.btnDanhMuc.Name = "btnDanhMuc";
            this.btnDanhMuc.Size = new System.Drawing.Size(267, 37);
            this.btnDanhMuc.TabIndex = 6;
            this.btnDanhMuc.Text = "DANH MỤC";
            this.btnDanhMuc.UseVisualStyleBackColor = false;
            this.btnDanhMuc.Click += new System.EventHandler(this.btnDanhMuc_Click);
            // 
            // panelHeThong
            // 
            this.panelHeThong.Controls.Add(this.btnDangKi);
            this.panelHeThong.Controls.Add(this.btnDoiMK);
            this.panelHeThong.Controls.Add(this.btnThongTinCN);
            this.panelHeThong.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelHeThong.Location = new System.Drawing.Point(0, 160);
            this.panelHeThong.Name = "panelHeThong";
            this.panelHeThong.Size = new System.Drawing.Size(267, 108);
            this.panelHeThong.TabIndex = 5;
            // 
            // btnDangKi
            // 
            this.btnDangKi.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btnDangKi.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnDangKi.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnDangKi.FlatAppearance.BorderSize = 0;
            this.btnDangKi.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDangKi.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDangKi.ForeColor = System.Drawing.Color.White;
            this.btnDangKi.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnDangKi.Location = new System.Drawing.Point(0, 74);
            this.btnDangKi.Margin = new System.Windows.Forms.Padding(4);
            this.btnDangKi.Name = "btnDangKi";
            this.btnDangKi.Size = new System.Drawing.Size(267, 37);
            this.btnDangKi.TabIndex = 7;
            this.btnDangKi.Text = "ĐĂNG XUẤT";
            this.btnDangKi.UseVisualStyleBackColor = false;
            this.btnDangKi.Click += new System.EventHandler(this.btnDangKi_Click);
            // 
            // btnDoiMK
            // 
            this.btnDoiMK.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btnDoiMK.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnDoiMK.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnDoiMK.FlatAppearance.BorderSize = 0;
            this.btnDoiMK.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDoiMK.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDoiMK.ForeColor = System.Drawing.Color.White;
            this.btnDoiMK.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnDoiMK.Location = new System.Drawing.Point(0, 37);
            this.btnDoiMK.Margin = new System.Windows.Forms.Padding(4);
            this.btnDoiMK.Name = "btnDoiMK";
            this.btnDoiMK.Size = new System.Drawing.Size(267, 37);
            this.btnDoiMK.TabIndex = 6;
            this.btnDoiMK.Text = "ĐỔI MẬT KHẨU";
            this.btnDoiMK.UseVisualStyleBackColor = false;
            this.btnDoiMK.Click += new System.EventHandler(this.btnDoiMK_Click);
            // 
            // btnThongTinCN
            // 
            this.btnThongTinCN.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btnThongTinCN.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnThongTinCN.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnThongTinCN.FlatAppearance.BorderSize = 0;
            this.btnThongTinCN.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnThongTinCN.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnThongTinCN.ForeColor = System.Drawing.Color.White;
            this.btnThongTinCN.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnThongTinCN.Location = new System.Drawing.Point(0, 0);
            this.btnThongTinCN.Margin = new System.Windows.Forms.Padding(4);
            this.btnThongTinCN.Name = "btnThongTinCN";
            this.btnThongTinCN.Size = new System.Drawing.Size(267, 37);
            this.btnThongTinCN.TabIndex = 5;
            this.btnThongTinCN.Text = "THÔNG TIN CÁ NHÂN";
            this.btnThongTinCN.UseVisualStyleBackColor = false;
            this.btnThongTinCN.Click += new System.EventHandler(this.btnThongTinCN_Click);
            // 
            // btnHeThong
            // 
            this.btnHeThong.BackColor = System.Drawing.Color.DimGray;
            this.btnHeThong.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnHeThong.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnHeThong.FlatAppearance.BorderSize = 0;
            this.btnHeThong.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnHeThong.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnHeThong.ForeColor = System.Drawing.Color.White;
            this.btnHeThong.Image = ((System.Drawing.Image)(resources.GetObject("btnHeThong.Image")));
            this.btnHeThong.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnHeThong.Location = new System.Drawing.Point(0, 123);
            this.btnHeThong.Margin = new System.Windows.Forms.Padding(4);
            this.btnHeThong.Name = "btnHeThong";
            this.btnHeThong.Size = new System.Drawing.Size(267, 37);
            this.btnHeThong.TabIndex = 4;
            this.btnHeThong.Text = "HỆ THỐNG";
            this.btnHeThong.UseVisualStyleBackColor = false;
            this.btnHeThong.Click += new System.EventHandler(this.btnHeThong_Click);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(267, 123);
            this.panel1.TabIndex = 3;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(84, 19);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(92, 81);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // mainpanel
            // 
            this.mainpanel.Controls.Add(this.label2);
            this.mainpanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.mainpanel.Location = new System.Drawing.Point(267, 37);
            this.mainpanel.Margin = new System.Windows.Forms.Padding(4);
            this.mainpanel.Name = "mainpanel";
            this.mainpanel.Size = new System.Drawing.Size(800, 563);
            this.mainpanel.TabIndex = 4;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Arial", 22.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label2.ForeColor = System.Drawing.Color.DimGray;
            this.label2.Location = new System.Drawing.Point(166, 257);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(504, 44);
            this.label2.TabIndex = 32;
            this.label2.Text = "WELCOME TO MY SYSTEM";
            // 
            // frmGiaodien
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1067, 600);
            this.Controls.Add(this.mainpanel);
            this.Controls.Add(this.panelside);
            this.Controls.Add(this.panelheader);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "frmGiaodien";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            this.panelheader.ResumeLayout(false);
            this.panelheader.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.panelside.ResumeLayout(false);
            this.panelThongKe.ResumeLayout(false);
            this.panelDanhMuc.ResumeLayout(false);
            this.panelHeThong.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.mainpanel.ResumeLayout(false);
            this.mainpanel.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panelheader;
        private System.Windows.Forms.Button btnclose;
        private System.Windows.Forms.Panel panelside;
        private System.Windows.Forms.Button btnHeThong;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button btnNapTien;
        private System.Windows.Forms.Button btnThemTK;
        private System.Windows.Forms.Panel panelDanhMuc;
        private System.Windows.Forms.Button btnDanhMuc;
        private System.Windows.Forms.Panel panelHeThong;
        private System.Windows.Forms.Panel mainpanel;
        private System.Windows.Forms.Button btnThongKe;
        private System.Windows.Forms.Button btnMay;
        private System.Windows.Forms.Panel panelThongKe;
        private System.Windows.Forms.Button btnThongTinCN;
        private System.Windows.Forms.Button btnDangKi;
        private System.Windows.Forms.Button btnDoiMK;
        private System.Windows.Forms.Button btnGiaoDich;
        private System.Windows.Forms.Button btnQLDichVu;
        private System.Windows.Forms.Button btnQLMay;
        private System.Windows.Forms.Button btnKhach;
        private System.Windows.Forms.Button btnNhanVien;
        private System.Windows.Forms.Button btnSuCo;
        private System.Windows.Forms.Button btnTKNgay;
        private System.Windows.Forms.Button btnTKthang;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label label2;
    }
}

