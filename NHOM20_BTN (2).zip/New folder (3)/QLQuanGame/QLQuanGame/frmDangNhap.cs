﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QLQuanGame
{
    
    public partial class frmDangNhap : Form
    {
        public static string username;
        public static string idnhanvien;
        public frmDangNhap()
        {
            InitializeComponent();
        }
        SqlConnection conn = new SqlConnection(@"Data Source=MSI\SQLEXPRESS;Initial Catalog=qlqgamee;Integrated Security=True");
        SqlCommand cmd = new SqlCommand();
        SqlDataAdapter adapter = new SqlDataAdapter();
        private void frmDangNhap_Load(object sender, EventArgs e)
        {

        }

        private void txtUsername_TextChanged(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {
            new frmDangKiTaiKhoan().Show();
            this.Hide();
        }

        private void clearButton_Click(object sender, EventArgs e)
        {
            txtUsername.Text = "";
            txtPassword.Text = "";
            txtUsername.Focus();
        }

        public void btnLogin_Click(object sender, EventArgs e)
        {
            try
            {
                if (conn != null && conn.State == ConnectionState.Open)
                {
                    conn.Close();
                }

                conn.Open();

                string loginQuery = "SELECT * FROM NhanVien WHERE username = @username AND password = @password";
                using (SqlCommand loginCmd = new SqlCommand(loginQuery, conn))
                {
                    loginCmd.Parameters.AddWithValue("@username", txtUsername.Text);
                    loginCmd.Parameters.AddWithValue("@password", txtPassword.Text);

                    using (SqlDataReader dr = loginCmd.ExecuteReader())
                    {
                        if (dr.Read())
                        {
                            idnhanvien = dr["idnhanvien"].ToString();
                            username = txtUsername.Text;
                            new frmGiaodien().Show();
                            this.Hide();
                        }
                        else
                        {
                            MessageBox.Show("Invalid Credentials, please try again.", "Login Failed", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            txtUsername.Text = "";
                            txtPassword.Text = "";
                            txtUsername.Focus();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message, "Login Failed", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                if (conn != null && conn.State == ConnectionState.Open)
                {
                    conn.Close();
                }
            }
        }

        private void checkboxShowPass_CheckedChanged(object sender, EventArgs e)
        {
            if (checkboxShowPass.Checked)
            {
                txtPassword.PasswordChar = '\0';
            }
            else
            {
                txtPassword.PasswordChar = '*';

            }
        }
    }
}
