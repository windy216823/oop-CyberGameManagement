﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QLQuanGame
{
    public partial class frmDoiMatKhau : Form
    {
        SqlConnection conn = new SqlConnection(@"Data Source=MSI\SQLEXPRESS;Initial Catalog=qlqgamee;Integrated Security=True");
        SqlCommand cmd = new SqlCommand();
        public frmDoiMatKhau()
        {
            InitializeComponent();
        }

        private void frmDoiMatKhau_Load(object sender, EventArgs e)
        {
            frmDangNhap frmDangNhap = new frmDangNhap();
            txtUserName.Text = frmDangNhap.username;
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            try
            {
                if (txtMKmoi.Text == "" || txtNhapLai.Text == "")
                {
                    MessageBox.Show("Vui lòng nhập đầy đủ!!!");
                }
                else if (txtNhapLai.Text != txtMKmoi.Text)
                {
                    MessageBox.Show("Mật khẩu không trùng khớp!!");
                }
                else
                {
                    if (conn.State == ConnectionState.Closed)
                    {
                        conn.Open();
                    }

                    string query = "UPDATE NhanVien SET password = @NewPassword WHERE username = @Username";
                    cmd = new SqlCommand(query, conn);
                    cmd.Parameters.AddWithValue("@NewPassword", txtMKmoi.Text);
                    cmd.Parameters.AddWithValue("@Username", txtUserName.Text);
                    cmd.ExecuteNonQuery();
                    conn.Close();
                    MessageBox.Show("Đổi thành công");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }
    }
}
