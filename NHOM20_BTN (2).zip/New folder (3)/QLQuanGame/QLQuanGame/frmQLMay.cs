﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QLQuanGame
{
    public partial class frmQLMay : Form
    {
        SqlConnection connection;
        SqlCommand command;
        string str = @"Data Source=MSI\SQLEXPRESS;Initial Catalog=qlqgamee;Integrated Security=True";
        SqlDataAdapter adapter = new SqlDataAdapter();
        DataTable table = new DataTable();
        void loadData()
        {
            command = connection.CreateCommand();
            command.CommandText = "Select * from May";
            adapter.SelectCommand = command;
            table.Clear();
            adapter.Fill(table);
            dgvListMay.DataSource = table;
        }
        public frmQLMay()
        {
            InitializeComponent();
        }

        private void frmQLMay_Load(object sender, EventArgs e)
        {
            connection = new SqlConnection(str);
            connection.Open();
            loadData();
        }

        private void dgvListMay_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            int i;
            i = dgvListMay.CurrentRow.Index;
            txtidmay.Text = dgvListMay.Rows[i].Cells[0].Value.ToString();
            txtTenMay.Text = dgvListMay.Rows[i].Cells[1].Value.ToString();
            txtstatus.Text = dgvListMay.Rows[i].Cells[2].Value.ToString();
        }

        private void btnThem_Click(object sender, EventArgs e)
        {
            command = connection.CreateCommand();
            command.CommandText = $"insert into May (idmay, hangmay, trangthai) values ('{txtidmay.Text}', '{txtTenMay.Text}', N'{txtstatus.Text}')";
            command.ExecuteNonQuery();
            loadData();

        }

        private void btnCapNhat_Click(object sender, EventArgs e)
        {
            
            command = connection.CreateCommand();
            command.CommandText = $"UPDATE May SET hangmay = '{txtTenMay.Text}', trangthai = N'{txtstatus.Text}' WHERE idmay = '{txtidmay.Text}'";
            command.ExecuteNonQuery();
            loadData();
        }

        private void btnXoa_Click(object sender, EventArgs e)
        {
            command = connection.CreateCommand();
            command.CommandText = "delete from May where idmay = '" + txtidmay.Text + "'";
            command.ExecuteNonQuery();
            loadData();
        }
    }
}
