﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.ComponentModel.Design.ObjectSelectorEditor;

namespace QLQuanGame
{
    public partial class frmTKThang : Form
    {
        public frmTKThang()
        {
            InitializeComponent();
        }

        private void frmTKThang_Load(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("Data Source=MSI\\SQLEXPRESS;Initial Catalog=qlqgamee;Integrated Security=True");
            DataSet ds = new DataSet();

            try
            {
                con.Open();
                SqlDataAdapter adapt = new SqlDataAdapter(@"SELECT
                                                    FORMAT(HD.ngaytao, 'MM-yyyy') AS Thang,
                                                    SUM(CTHD.soluong * DV.dongia) AS DoanhThuThang
                                                FROM
                                                    HoaDon HD
                                                JOIN
                                                    ChiTietHoaDon CTHD ON HD.idbill = CTHD.idbill
                                                JOIN
                                                    DichVu DV ON CTHD.iddichvu = DV.iddichvu
                                                GROUP BY
                                                    FORMAT(HD.ngaytao, 'MM-yyyy')", con);
                adapt.Fill(ds, "DoanhThuThangData");
                chartThang.DataSource = ds.Tables["DoanhThuThangData"];

                // Đặt các thuộc tính giao diện của biểu đồ
                chartThang.Series[0].ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Column;
                chartThang.Series[0].XValueMember = "Thang";
                chartThang.Series[0].YValueMembers = "DoanhThuThang";
                chartThang.Titles.Add("Biểu đồ doanh thu theo tháng");

                SqlCommand cmd = new SqlCommand(@"SELECT
                                SUM(CTHD.soluong * DV.dongia) AS TongDoanhThu
                            FROM
                                HoaDon HD
                            JOIN
                                ChiTietHoaDon CTHD ON HD.idbill = CTHD.idbill
                            JOIN
                                DichVu DV ON CTHD.iddichvu = DV.iddichvu
                            WHERE
                                HD.ngaytao BETWEEN '2023-01-01' AND '2023-12-31';", con);
                SqlDataReader dr = cmd.ExecuteReader();
                textBox1.Text = dr[0].ToString();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
            finally
            {
                con.Close();
            }
        }

        private void chartThang_Click(object sender, EventArgs e)
        {

        }
    }
}
