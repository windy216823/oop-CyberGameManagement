﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QLQuanGame
{
    public partial class frmSuCo : Form
    {
        public frmSuCo()
        {
            InitializeComponent();
        }

        private void frmSuCo_Load(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("Data Source=MSI\\SQLEXPRESS;Initial Catalog=qlqgamee;Integrated Security=True");
            DataSet ds = new DataSet();
            try
            {
                
                con.Open();

                
                SqlDataAdapter adapt = new SqlDataAdapter(@"SELECT ngaygapsuco, chiphi FROM GapSuCo", con);
                adapt.Fill(ds, "SuCoData");

                // Đặt các thuộc tính giao diện của biểu đồ
                chart1.Series[0].ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Column;
                chart1.Series[0].XValueMember = "ngaygapsuco";  // Đặt tên trường cho trục x
                chart1.Series[0].YValueMembers = "chiphi";     // Đặt tên trường cho trục y
                chart1.Titles.Add("Biểu đồ sự cố");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
            finally
            {
                con.Close();
            }
        }
    }
}
