﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;

namespace QLQuanGame
{
    public partial class frmNapTien : Form
    {
        SqlConnection conn = new SqlConnection(@"Data Source=MSI\SQLEXPRESS;Initial Catalog=qlqgamee;Integrated Security=True");
        SqlCommand cmd;

        public frmNapTien()
        {
            InitializeComponent();
            // Gắn sự kiện TextChanged cho txtTienNap để cập nhật giá trị của txtTime khi người dùng thay đổi nó
            txtTienNap.TextChanged += TxtTienNap_TextChanged;
        }

        private void TxtTienNap_TextChanged(object sender, EventArgs e)
        {
            // Kiểm tra xem người dùng đã nhập giá trị hợp lệ hay chưa
            if (float.TryParse(txtTienNap.Text, out float tienNap))
            {
                // Tính toán giá trị của txtTime dưới dạng TimeSpan
                TimeSpan timeSpan = TimeSpan.FromHours(tienNap / 5000.0f);

                // Hiển thị giá trị của txtTime dưới định dạng thời gian
                txtTime.Text = $"{timeSpan.Hours:D2}:{timeSpan.Minutes:D2}:{timeSpan.Seconds:D2}";
            }
            else
            {
                // Nếu giá trị nhập không hợp lệ, có thể hiển thị thông báo hoặc xử lý khác tùy thuộc vào yêu cầu của bạn.
                txtTime.Text = "0:00:00";
            }
        }

        private void frmNapTien_Load(object sender, EventArgs e)
        {

        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            try
            {
                using (SqlConnection conn = new SqlConnection(@"Data Source=MSI\SQLEXPRESS;Initial Catalog=qlqgamee;Integrated Security=True"))
                {
                    conn.Open();

                    string querySelect = "SELECT * FROM Khach WHERE accountname = @userName";
                    using (SqlCommand selectCmd = new SqlCommand(querySelect, conn))
                    {
                        selectCmd.Parameters.AddWithValue("@userName", txtUserName.Text);
                        SqlDataReader dr = selectCmd.ExecuteReader();

                        if (dr.Read())
                        {
                            string queryInsert = "INSERT INTO NapTien (idnhanvien, idkhach, sotien, ngaygionap) " +
                                                "VALUES (@idnhanvien, @idkhach, @sotien, @ngaygionap)";

                            using (SqlCommand insertCmd = new SqlCommand(queryInsert, conn))
                            {
                                insertCmd.Parameters.AddWithValue("@idnhanvien", frmDangNhap.idnhanvien);
                                insertCmd.Parameters.AddWithValue("@idkhach", dr[0].ToString());
                                insertCmd.Parameters.AddWithValue("@sotien", Convert.ToDouble(txtTienNap.Text));
                                insertCmd.Parameters.AddWithValue("@ngaygionap", DateTime.Now);

                                insertCmd.ExecuteNonQuery();
                                MessageBox.Show("Thành công!!");
                            }

                            // Cập nhật remaintime trong bảng Khach
                            if (double.TryParse(txtTime.Text, out double remainTime))
                            {
                                string queryUpdateRemainTime = "UPDATE Khach SET remaintime = DATEADD(SECOND, @remainTime, remaintime) WHERE accountname = @userName";

                                using (SqlCommand updateRemainTimeCmd = new SqlCommand(queryUpdateRemainTime, conn))
                                {
                                    updateRemainTimeCmd.Parameters.AddWithValue("@remainTime", remainTime);
                                    updateRemainTimeCmd.Parameters.AddWithValue("@userName", txtUserName.Text);

                                    updateRemainTimeCmd.ExecuteNonQuery();
                                }
                            }
                            else
                            {
                                MessageBox.Show("Giá trị thời gian không hợp lệ");
                            }
                        }
                        else
                        {
                            MessageBox.Show("Tài khoản không tồn tại");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi: " + ex.Message);
            }
        }
    }
}
