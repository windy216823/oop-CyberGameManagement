﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QLQuanGame
{
    public partial class frmGiaodien : Form
    {
        private Boolean showPanelHeThong = false;
        private Boolean showPanelDanhMuc = false;
        private Boolean showPanelThongKe = false;
        public frmGiaodien()
        {
            InitializeComponent();

            tooglePanels();
        }
        public void loadform(object Form)
        {
            if (this.mainpanel.Controls.Count > 0)
                this.mainpanel.Controls.RemoveAt(0);
            Form f = Form as Form;
            f.TopLevel = false;
            f.Dock = DockStyle.Fill;
            this.mainpanel.Controls.Add(f);
            this.mainpanel.Tag = f;
            f.Show();
        }
        private void tooglePanels()
        {
            if (showPanelHeThong)
            {
                panelHeThong.Height = 111;
            }
            else
            {
                panelHeThong.Height = 0;
            }

            if (showPanelDanhMuc)
            {
                panelDanhMuc.Height = 185;
            }
            else
            {
                panelDanhMuc.Height = 0;
            }

            if (showPanelThongKe)
            {
                panelThongKe.Height = 111;
            }
            else
            {
                panelThongKe.Height = 0;
            }
        }

        private void btnclose_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btnHeThong_Click(object sender, EventArgs e)
        {
            showPanelHeThong = !showPanelHeThong;
            tooglePanels();
        }

        private void btnDanhMuc_Click(object sender, EventArgs e)
        {
            showPanelDanhMuc = !showPanelDanhMuc;
            tooglePanels();
        }

        private void btnThongKe_Click(object sender, EventArgs e)
        {
            showPanelThongKe = !showPanelThongKe;
            tooglePanels();
        }

        private void btnThongTinCN_Click(object sender, EventArgs e)
        {
            loadform(new frmThongTinCaNhan());
        }

        private void btnDoiMK_Click(object sender, EventArgs e)
        {
            loadform(new frmDoiMatKhau());
        }

        private void btnDangKi_Click(object sender, EventArgs e)
        {
            DialogResult res =  MessageBox.Show("Bạn chắc chắn muốn đăng xuất?", "Đăng xuất", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
            if(res == DialogResult.Yes)
            {
                new frmDangNhap().Show();
                this.Hide();
            }
            
        }

        private void btnNhanVien_Click(object sender, EventArgs e)
        {
            loadform(new frmQLNV());
        }

        private void btnKhach_Click(object sender, EventArgs e)
        {
            loadform(new frmQLKhach());
        }

        private void btnQLMay_Click(object sender, EventArgs e)
        {
            loadform(new frmQLMay());
        }

        private void btnQLDichVu_Click(object sender, EventArgs e)
        {
            loadform(new frmQLDichVu());
        }

        private void btnGiaoDich_Click(object sender, EventArgs e)
        {
            loadform(new frmQLGiaoDich());
        }

        private void btnThemTK_Click(object sender, EventArgs e)
        {
            loadform(new frmAddAccount());
        }

        private void btnNapTien_Click(object sender, EventArgs e)
        {
            loadform(new frmNapTien());
        }

        private void btnThanhToanDV_Click(object sender, EventArgs e)
        {
            loadform(new frmTTDV());
        }

        private void btnMay_Click(object sender, EventArgs e)
        {
            loadform(new frmMay());
        }

        private void btnTKthang_Click(object sender, EventArgs e)
        {
            loadform(new frmTKThang());
        }

        private void btnTKNgay_Click(object sender, EventArgs e)
        {
            loadform(new frmTKNgay());
        }

        private void btnSuCo_Click(object sender, EventArgs e)
        {
            loadform(new frmSuCo());
        }
    }
}
