﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QLQuanGame
{
    public partial class frmAddAccount : Form
    {
        SqlConnection conn = new SqlConnection(@"Data Source=MSI\SQLEXPRESS;Initial Catalog=qlqgamee;Integrated Security=True");
        SqlCommand cmd;
        public frmAddAccount()
        {
            InitializeComponent();
        }

        private void frmAddAccount_Load(object sender, EventArgs e)
        {
            
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            try
            {
                if (txtUserName.Text == "" || txtMK.Text == "" || txtNhapLai.Text == "")
                {
                    MessageBox.Show("Điền đầy đủ thông tin!");
                }else if(txtMK.Text != txtNhapLai.Text)
                {
                    MessageBox.Show("Mat khau khong khop!!!");
                }
                else
                {
                    if (conn.State == ConnectionState.Closed)
                    {
                        conn.Open();
                    }

                    // Sử dụng thời gian mặc định '00:00:00.000' cho remaintime
                    string query = "INSERT INTO Khach (accountname, password, remaintime, sdt) VALUES (@AccountName, @Password, '00:00:00.000', @PhoneNumber)";
                    cmd = new SqlCommand(query, conn);
                    cmd.Parameters.AddWithValue("@AccountName", txtUserName.Text);
                    // Băm mật khẩu trước khi lưu vào cơ sở dữ liệu
                    cmd.Parameters.AddWithValue("@Password", txtMK.Text);
                    cmd.Parameters.AddWithValue("@PhoneNumber", textBox1.Text);
                    cmd.ExecuteNonQuery();
                    conn.Close();
                    MessageBox.Show("Thêm tài khoản thành công");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
