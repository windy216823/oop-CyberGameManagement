﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;

namespace QLQuanGame
{
    public partial class frmTKNgay : Form
    {
        public frmTKNgay()
        {
            InitializeComponent();
        }

        private void frmTKNgay_Load(object sender, EventArgs e)
        {
            fillChart(); 
        }
        private void fillChart()
        {
            SqlConnection con = new SqlConnection("Data Source=MSI\\SQLEXPRESS;Initial Catalog=qlqgamee;Integrated Security=True");
            DataSet ds = new DataSet();

            try
            {
                con.Open();
                SqlDataAdapter adapt = new SqlDataAdapter(@"SELECT
                                                    HD.ngaytao AS Ngay,
                                                    CTHD.soluong * DV.dongia AS thanhtien
                                                FROM
                                                    HoaDon HD
                                                JOIN
                                                    ChiTietHoaDon CTHD ON HD.idbill = CTHD.idbill
                                                JOIN
                                                    DichVu DV ON CTHD.iddichvu = DV.iddichvu", con);
                adapt.Fill(ds, "HoaDonData");
                chartNgay.DataSource = ds.Tables["HoaDonData"];

                // Đặt các thuộc tính giao diện của biểu đồ
                chartNgay.Series[0].ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Column;
                chartNgay.Series[0].XValueMember = "Ngay";
                chartNgay.Series[0].YValueMembers = "thanhtien";
                chartNgay.Titles.Add("Biểu đồ doanh thu theo ngày");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
            finally
            {
                con.Close();
            }
        }
    }
}
