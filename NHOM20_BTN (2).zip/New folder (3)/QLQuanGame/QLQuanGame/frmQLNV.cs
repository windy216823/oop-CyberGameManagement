﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QLQuanGame
{
    public partial class frmQLNV : Form
    {
        SqlConnection connection;
        SqlCommand command;
        string str = @"Data Source=MSI\SQLEXPRESS;Initial Catalog=qlqgamee;Integrated Security=True";
        SqlDataAdapter adapter = new SqlDataAdapter();
        DataTable table = new DataTable();
        void loadData()
        {
            command = connection.CreateCommand();
            command.CommandText = "Select * from NhanVien";
            adapter.SelectCommand = command;
            table.Clear();
            adapter.Fill(table);
            dgvlistnv.DataSource = table;
        }

        public frmQLNV()
        {
            InitializeComponent();
        }

        private void frmQLNV_Load(object sender, EventArgs e)
        {
            connection = new SqlConnection(str);
            connection.Open();
            command = connection.CreateCommand();
            command.CommandText = "Select * from NhanVien";
            adapter.SelectCommand = command;
            table.Clear();
            adapter.Fill(table);

            dgvlistnv.DataSource = table;

            dgvlistnv.Columns["hoten"].HeaderText = "Họ tên";

        }

        private void btnFind_Click(object sender, EventArgs e)
        {
            try
            {
                if (connection.State == ConnectionState.Closed)
                {
                    connection.Open();
                }

                string query = "SELECT * FROM NhanVien WHERE idnhanvien = @idnhanvien";
                command = connection.CreateCommand();
                command.CommandText = query;
                command.Parameters.AddWithValue("@idnhanvien", txtID.Text);

                adapter.SelectCommand = command;
                table.Clear();
                adapter.Fill(table);
                dgvlistnv.DataSource = table;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi: " + ex.Message);
            }
            finally
            {
                if (connection.State == ConnectionState.Open)
                {
                    connection.Close();
                }
            }
        }
    }
}
